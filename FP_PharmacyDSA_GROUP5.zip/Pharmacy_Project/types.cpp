#include "types.h"

const char* const CITY_NAMES[NUM_CITIES] = {
    "Quezon City", "Marikina City", "Antipolo City", "Pasig City", "Rizal Province"};

std::string branchName(int id) {
    if (id < 0 || id >= NUM_BRANCHES) return "Unknown";
    return std::string(CITY_NAMES[cityOfBranch(id)]) + " - Branch " +
           std::to_string(id % BRANCHES_PER_CITY + 1);
}

std::string statusToString(OrderStatus s) {
    switch (s) {
        case OrderStatus::PENDING: return "PENDING";
        case OrderStatus::SERVED: return "SERVED";
        default: return "CANCELLED";
    }
}

OrderStatus statusFromString(const std::string& s) {
    if (s == "SERVED") return OrderStatus::SERVED;
    if (s == "CANCELLED") return OrderStatus::CANCELLED;
    return OrderStatus::PENDING;
}
