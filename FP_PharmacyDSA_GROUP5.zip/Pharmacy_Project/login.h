#pragma once
#include <string>
#include "types.h"

bool validateName(const std::string& name);
Session loginCustomer();
bool loginAdmin(Session& s);
int chooseBranchFromAll(const std::string& prompt);
