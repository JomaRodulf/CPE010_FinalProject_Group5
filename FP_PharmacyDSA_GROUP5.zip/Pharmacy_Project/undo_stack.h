#pragma once
#include <string>
#include <vector>
#include "types.h"

struct AppState;

enum class ChangeType { ADD_BATCHES, UPDATE_QTY, RELEASE_FRONT, REMOVE_EXPIRED };

struct StockChange {
    ChangeType type = ChangeType::ADD_BATCHES;
    int branch = 0;
    std::vector<Batch> batches;

    int newQty = 0;
    std::string when;
    std::string describe() const;
};

class UndoStack {
public:
    UndoStack() = default;
    ~UndoStack() { clear(); }
    UndoStack(const UndoStack&) = delete;
    UndoStack& operator=(const UndoStack&) = delete;

    void push(const StockChange& c);
    bool pop(StockChange& out);
    bool peek(StockChange& out) const;
    bool isEmpty() const { return top_ == nullptr; }
    int size() const { return count_; }
    std::vector<StockChange> toVector() const;
    void clear();

    static constexpr int MAX_HISTORY = 30;

private:
    struct Node { StockChange data; Node* next; };
    Node* top_ = nullptr;
    int count_ = 0;
};

StockChange makeAdded(int branch, const std::vector<Batch>& batches);
StockChange makeUpdated(int branch, const Batch& before, int newQty);
StockChange makeReleased(int branch, const Batch& batch);
StockChange makeExpiredRemoved(int branch, const std::vector<Batch>& batches);

bool applyUndo(AppState& s, const StockChange& c, std::string& message);

void undoLastUpdate();
void showUpdateHistory();
