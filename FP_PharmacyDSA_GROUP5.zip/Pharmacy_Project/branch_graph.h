#pragma once
#include <array>
#include <functional>
#include <vector>
#include "types.h"

class BranchGraph {
public:
    BranchGraph() { resetDefault(); }

    void resetDefault();
    bool addEdge(int a, int b);
    bool removeEdge(int a, int b);
    bool hasEdge(int a, int b) const;
    const std::vector<int>& neighbors(int b) const { return adj_[b]; }
    std::vector<std::pair<int, int>> edges() const;

    struct Found {
        bool found = false;
        int branch = -1;
        int hops = 0;
        std::vector<int> path;
    };

    Found nearest(int start, const std::function<bool(int)>& ok) const;
    std::vector<int> shortestPath(int from, int to) const;
    void printTree(int root) const;

private:
    std::array<std::vector<int>, NUM_BRANCHES> adj_;
};

void branchMenu();
void rebalanceMenu();
