#include "branch_graph.h"
#include <algorithm>
#include <iostream>
#include <queue>
#include "catalog.h"
#include "data_store.h"
#include "expiry_sort.h"
#include "login.h"
#include "ui.h"
#include "util.h"

void BranchGraph::resetDefault() {
    for (auto& v : adj_) v.clear();

    for (int c = 0; c < NUM_CITIES; ++c) addEdge(c * BRANCHES_PER_CITY, c * BRANCHES_PER_CITY + 1);

    const int cityLinks[][2] = {{0, 1}, {0, 3}, {1, 3}, {1, 2}, {2, 4}, {3, 4}};
    for (const auto& l : cityLinks) addEdge(l[0] * BRANCHES_PER_CITY, l[1] * BRANCHES_PER_CITY);
}

bool BranchGraph::hasEdge(int a, int b) const {
    if (a < 0 || b < 0 || a >= NUM_BRANCHES || b >= NUM_BRANCHES) return false;
    return std::find(adj_[a].begin(), adj_[a].end(), b) != adj_[a].end();
}

bool BranchGraph::addEdge(int a, int b) {
    if (a == b || a < 0 || b < 0 || a >= NUM_BRANCHES || b >= NUM_BRANCHES || hasEdge(a, b)) return false;
    adj_[a].push_back(b);
    adj_[b].push_back(a);
    std::sort(adj_[a].begin(), adj_[a].end());
    std::sort(adj_[b].begin(), adj_[b].end());
    return true;
}

bool BranchGraph::removeEdge(int a, int b) {
    if (!hasEdge(a, b)) return false;
    adj_[a].erase(std::remove(adj_[a].begin(), adj_[a].end(), b), adj_[a].end());
    adj_[b].erase(std::remove(adj_[b].begin(), adj_[b].end(), a), adj_[b].end());
    return true;
}

std::vector<std::pair<int, int>> BranchGraph::edges() const {
    std::vector<std::pair<int, int>> out;
    for (int a = 0; a < NUM_BRANCHES; ++a)
        for (int b : adj_[a])
            if (a < b) out.push_back({a, b});
    return out;
}

BranchGraph::Found BranchGraph::nearest(int start, const std::function<bool(int)>& ok) const {
    Found f;
    if (start < 0 || start >= NUM_BRANCHES) return f;
    std::array<int, NUM_BRANCHES> parent;
    std::array<int, NUM_BRANCHES> dist{};
    parent.fill(-2);
    std::queue<int> q;
    parent[start] = -1;
    q.push(start);
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        if (ok(u)) {
            f.found = true;
            f.branch = u;
            f.hops = dist[u];
            for (int v = u; v != -1; v = parent[v]) f.path.push_back(v);
            std::reverse(f.path.begin(), f.path.end());
            return f;
        }
        for (int v : adj_[u]) {
            if (parent[v] != -2) continue;
            parent[v] = u;
            dist[v] = dist[u] + 1;
            q.push(v);
        }
    }
    return f;
}

std::vector<int> BranchGraph::shortestPath(int from, int to) const {
    return nearest(from, [to](int b) { return b == to; }).path;
}

static void printSubtree(int node, const std::vector<std::vector<int>>& kids, const std::string& prefix) {
    for (size_t i = 0; i < kids[node].size(); ++i) {
        bool last = (i + 1 == kids[node].size());
        int k = kids[node][i];
        std::cout << prefix << (last ? "`-- " : "|-- ") << branchName(k) << "\n";
        printSubtree(k, kids, prefix + (last ? "    " : "|   "));
    }
}

void BranchGraph::printTree(int root) const {
    std::vector<std::vector<int>> kids(NUM_BRANCHES);
    std::array<bool, NUM_BRANCHES> seen{};
    std::queue<int> q;
    seen[root] = true;
    q.push(root);
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : adj_[u])
            if (!seen[v]) { seen[v] = true; kids[u].push_back(v); q.push(v); }
    }
    std::cout << ui::bold(branchName(root)) << "  (root)\n";
    printSubtree(root, kids, "");
    bool any = false;
    for (int b = 0; b < NUM_BRANCHES; ++b)
        if (!seen[b]) {
            if (!any) std::cout << "\nNot connected to this branch:\n";
            any = true;
            std::cout << "  - " << branchName(b) << "\n";
        }
}

void branchMenu() {
    while (true) {
        ui::header("BRANCH NETWORK (Graph + BFS)");
        std::cout << " 1. View network as a BFS tree\n"
                  << " 2. List all branch links\n"
                  << " 3. Link two branches (add edge)\n"
                  << " 4. Unlink two branches (remove edge)\n"
                  << " 5. Find the shortest route between two branches\n"
                  << " 0. Back\n";
        int c = readInt("Choice: ", 0, 5);
        if (c == 0) return;

        if (c == 1) {
            int b = chooseBranchFromAll("Draw the network starting from");
            Transaction tx(false);
            std::cout << "\n";
            tx.state().graph.printTree(b);
            pauseScreen();
        } else if (c == 2) {
            Transaction tx(false);
            auto e = tx.state().graph.edges();
            std::cout << "\n" << e.size() << " link(s):\n";
            for (auto& p : e) std::cout << "  " << fit(branchName(p.first), 28) << " <--> " << branchName(p.second) << "\n";
            pauseScreen();
        } else if (c == 3 || c == 4) {
            int a = chooseBranchFromAll("First branch");
            int b = chooseBranchFromAll("Second branch");
            if (a == b) { ui::err("A branch cannot be linked to itself."); continue; }
            Transaction tx;
            bool done = (c == 3) ? tx.state().graph.addEdge(a, b) : tx.state().graph.removeEdge(a, b);
            if (done) {
                tx.commit();
                ui::ok(branchName(a) + (c == 3 ? " is now linked to " : " is no longer linked to ") + branchName(b) + ".");
            } else {
                ui::warn(c == 3 ? "Those branches are already linked." : "Those branches are not linked.");
            }
        } else {
            int a = chooseBranchFromAll("Route from");
            int b = chooseBranchFromAll("Route to");
            Transaction tx(false);
            std::vector<int> path = tx.state().graph.shortestPath(a, b);
            if (path.empty()) { ui::warn("No route - the branches are not connected."); continue; }
            std::cout << "\nShortest route (" << path.size() - 1 << " hop(s)):\n  ";
            for (size_t i = 0; i < path.size(); ++i) std::cout << (i ? "  ->  " : "") << branchName(path[i]);
            std::cout << "\n";
            pauseScreen();
        }
    }
}

void rebalanceMenu() {
    ui::header("LOWEST-STOCK FINDER & RE-ALLOCATION");
    Catalog cat = buildCatalog();
    int idx;
    if (!pickProduct(cat, idx)) return;
    const std::string code = cat.products()[idx].code;
    const std::string pname = cat.products()[idx].name;

    std::array<int, NUM_BRANCHES> stock{};
    {
        Transaction tx(false);
        for (int b = 0; b < NUM_BRANCHES; ++b) stock[b] = tx.state().inv[b].sellableStock(code);
    }
    int low = 0;
    for (int b = 1; b < NUM_BRANCHES; ++b)
        if (stock[b] < stock[low]) low = b;

    std::cout << "\n" << ui::bold(code + " - " + pname) << "   (minimum per branch: " << LOW_STOCK_THRESHOLD << " units)\n";
    printLine('-', 60);
    for (int b = 0; b < NUM_BRANCHES; ++b) {
        std::string tag = stock[b] < LOW_STOCK_THRESHOLD ? ui::red("LOW") : "";
        if (b == low) tag += ui::yellow(" <- lowest");
        std::cout << "  " << fit(branchName(b), 28) << fit(std::to_string(stock[b]) + " units", 12) << tag << "\n";
    }
    printLine('-', 60);

    if (stock[low] >= LOW_STOCK_THRESHOLD) {
        ui::ok("No branch is below the minimum for this medicine. Nothing to re-allocate.");
        pauseScreen();
        return;
    }
    if (!confirm("Re-allocate stock to " + branchName(low) + " from the nearest branches with surplus?")) return;

    std::vector<std::string> log;
    int moved = 0;
    {
        Transaction tx;
        AppState& s = tx.state();
        int need = 2 * LOW_STOCK_THRESHOLD - s.inv[low].sellableStock(code);
        while (need > 0) {
            BranchGraph::Found f = s.graph.nearest(low, [&](int b) {
                return b != low && s.inv[b].sellableStock(code) > LOW_STOCK_THRESHOLD;
            });
            if (!f.found) break;
            int give = std::min(need, s.inv[f.branch].sellableStock(code) - LOW_STOCK_THRESHOLD);
            Batch info;
            s.inv[f.branch].findInfo(code, info);
            std::string alloc;
            if (!s.inv[f.branch].deductFIFO(code, give, alloc)) break;
            for (const auto& part : parseAllocation(alloc)) {
                Batch nb = info;
                nb.expiry = part.first;
                nb.qty = part.second;
                s.inv[low].restore(nb);
            }
            log.push_back("Shipped " + std::to_string(give) + " units from " + branchName(f.branch) + " (" +
                          std::to_string(f.hops) + " hop(s) away)");
            need -= give;
            moved += give;
        }
        if (moved > 0) {
            insertionSortByExpiry(s.inv[low]);
            tx.commit();
        }
    }
    std::cout << "\n";
    for (const auto& l : log) ui::ok(l);
    if (moved == 0) ui::warn("No connected branch has surplus stock to send.");
    else ui::ok("Total re-allocated to " + branchName(low) + ": " + std::to_string(moved) + " units.");
    pauseScreen();
}
