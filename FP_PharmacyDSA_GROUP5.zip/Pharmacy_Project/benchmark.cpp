#include "benchmark.h"
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <fstream>
#include <iostream>
#include <random>
#include <string>
#include <vector>
#include "expiry_sort.h"
#include "inventory_queue.h"
#include "ui.h"
#include "util.h"

namespace {
using Clock = std::chrono::steady_clock;

double msSince(Clock::time_point t0) {
    return std::chrono::duration<double, std::milli>(Clock::now() - t0).count();
}

std::string codeAt(int i) {
    int letters = i / 10000, digits = i % 10000;
    std::string s(3, 'A');
    for (int k = 2; k >= 0; --k) { s[k] = static_cast<char>('A' + letters % 26); letters /= 26; }
    char buf[8];
    std::snprintf(buf, sizeof buf, "%04d", digits);
    return s + buf;
}

int binarySearch(const std::vector<std::string>& v, const std::string& key) {
    int lo = 0, hi = static_cast<int>(v.size()) - 1;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        int c = key.compare(v[mid]);
        if (c == 0) return mid;
        if (c < 0) hi = mid - 1; else lo = mid + 1;
    }
    return -1;
}
int linearSearch(const std::vector<std::string>& v, const std::string& key) {
    for (size_t i = 0; i < v.size(); ++i)
        if (v[i] == key) return static_cast<int>(i);
    return -1;
}

std::string randomDate(std::mt19937& g) {
    char buf[32];
    std::snprintf(buf, sizeof buf, "%04d-%02d-%02d", 2027 + static_cast<int>(g() % 6), 1 + static_cast<int>(g() % 12),
                  1 + static_cast<int>(g() % 28));
    return buf;
}

std::string orderedDate(int i) {
    char buf[32];
    std::snprintf(buf, sizeof buf, "%04d-%02d-%02d", 2027 + i / (12 * 28), (i / 28) % 12 + 1, i % 28 + 1);
    return buf;
}

Batch makeBatch(const std::string& expiry) {
    Batch b;
    b.code = "BEN0001"; b.name = "Benchmark"; b.qty = 1; b.price = 1.0; b.expiry = expiry;
    return b;
}

struct Row {
    int n = 0;
    double binary = 0, linear = 0, sortRandom = 0, sortNearly = 0, queueOps = 0;
};

volatile int g_sink = 0;

Row measure(int n, int runs, std::mt19937& rng) {
    Row r;
    r.n = n;
    const int LOOKUPS = 1000;
    std::vector<std::string> codes;
    codes.reserve(n);
    for (int i = 0; i < n; ++i) codes.push_back(codeAt(i));
    std::vector<std::string> keys;
    for (int i = 0; i < LOOKUPS; ++i) keys.push_back(codes[(static_cast<long long>(i) * 7919) % n]);

    for (int run = 1; run <= runs; ++run) {
        std::cout << "\r  n = " << n << "  run " << run << "/" << runs << "   " << std::flush;

        auto t = Clock::now();
        int acc = 0;
        for (const auto& k : keys) acc += binarySearch(codes, k);
        r.binary += msSince(t);

        t = Clock::now();
        for (const auto& k : keys) acc += linearSearch(codes, k);
        r.linear += msSince(t);
        g_sink = acc;

        {
            BranchQueue q;
            for (int i = 0; i < n; ++i) q.enqueue(makeBatch(randomDate(rng)));
            t = Clock::now();
            insertionSortByExpiry(q);
            r.sortRandom += msSince(t);
        }
        {
            BranchQueue q;
            for (int i = 0; i < n; ++i) q.enqueue(makeBatch(orderedDate(i)));
            for (int i = 0; i < std::max(1, n / 100); ++i) q.enqueue(makeBatch(randomDate(rng)));
            t = Clock::now();
            insertionSortByExpiry(q);
            r.sortNearly += msSince(t);
        }
        {
            BranchQueue q;
            Batch b = makeBatch("2030-01-01"), out;
            t = Clock::now();
            for (int i = 0; i < n; ++i) q.enqueue(b);
            for (int i = 0; i < n; ++i) q.dequeue(out);
            r.queueOps += msSince(t);
        }
    }
    std::cout << "\r" << std::string(40, ' ') << "\r";
    r.binary /= runs; r.linear /= runs; r.sortRandom /= runs; r.sortNearly /= runs; r.queueOps /= runs;
    return r;
}

std::string num(double v) {
    char buf[32];
    std::snprintf(buf, sizeof buf, "%.3f", v);
    return buf;
}
std::string growth(double cur, double prev) {
    if (prev < 0.005) return "n/a";
    char buf[32];
    std::snprintf(buf, sizeof buf, "x%.1f", cur / prev);
    return buf;
}
}

void benchmarkMenu() {
    ui::header("PERFORMANCE ANALYSIS (std::chrono)");
    std::cout << "Operations measured on synthetic data (real inventory is not touched):\n"
              << "  - Binary search      : 1,000 lookups in a sorted list of n codes      O(log n) each\n"
              << "  - Linear search      : the same 1,000 lookups, for comparison         O(n) each\n"
              << "  - Insertion sort     : n batches with random expiry dates (linked list)\n"
              << "  - Insertion sort     : restock case - n sorted batches + 1% new ones\n"
              << "  - Linked-list queue  : n enqueues followed by n dequeues              O(1) each\n\n"
              << " 1. Quick test      n = 100, 1,000, 10,000\n"
              << " 2. Full test       n = 100, 1,000, 10,000, 100,000  (can take several minutes)\n"
              << " 0. Back\n";
    int c = readInt("Choice: ", 0, 2);
    if (c == 0) return;
    std::vector<int> sizes = {100, 1000, 10000};
    if (c == 2) sizes.push_back(100000);
    int runs = readInt("Runs per input size (1-10, documentation uses 5): ", 1, 10);

    std::mt19937 rng(42);
    std::vector<Row> rows;
    std::cout << "\nRunning...\n";
    for (int n : sizes) rows.push_back(measure(n, runs, rng));

    std::cout << "\nAverage time in milliseconds over " << runs << " run(s):\n";
    printLine('=', 94);
    std::cout << fit("n", 10) << fit("Binary x1000", 15) << fit("Linear x1000", 15) << fit("Ins.sort random", 17)
              << fit("Ins.sort restock", 18) << fit("Queue enq+deq", 15) << "\n";
    printLine('-', 94);
    for (const Row& r : rows)
        std::cout << fit(std::to_string(r.n), 10) << fit(num(r.binary), 15) << fit(num(r.linear), 15)
                  << fit(num(r.sortRandom), 17) << fit(num(r.sortNearly), 18) << fit(num(r.queueOps), 15) << "\n";
    printLine('=', 94);

    std::cout << "\nGrowth when n grows 10x (compare with the Big-O prediction):\n";
    printLine('-', 94);
    std::cout << fit("n", 10) << fit("Binary", 15) << fit("Linear", 15) << fit("Ins.sort random", 17)
              << fit("Ins.sort restock", 18) << fit("Queue", 15) << "\n";
    for (size_t i = 1; i < rows.size(); ++i)
        std::cout << fit(std::to_string(rows[i].n), 10) << fit(growth(rows[i].binary, rows[i - 1].binary), 15)
                  << fit(growth(rows[i].linear, rows[i - 1].linear), 15)
                  << fit(growth(rows[i].sortRandom, rows[i - 1].sortRandom), 17)
                  << fit(growth(rows[i].sortNearly, rows[i - 1].sortNearly), 18)
                  << fit(growth(rows[i].queueOps, rows[i - 1].queueOps), 15) << "\n";
    printLine('-', 94);
    std::cout << "Expected per 10x n:  binary ~x1 (tiny change)   linear ~x10   queue ~x10 (n ops)   insertion sort ~x100\n";

    std::ofstream f("data/benchmark_results.csv");
    f << "n,binary_search_ms,linear_search_ms,insertion_sort_random_ms,insertion_sort_restock_ms,queue_enq_deq_ms\n";
    for (const Row& r : rows)
        f << r.n << ',' << r.binary << ',' << r.linear << ',' << r.sortRandom << ',' << r.sortNearly << ',' << r.queueOps << '\n';
    ui::ok("Results saved to data/benchmark_results.csv (ready for the Figure 5 line graph).");
    pauseScreen();
}
