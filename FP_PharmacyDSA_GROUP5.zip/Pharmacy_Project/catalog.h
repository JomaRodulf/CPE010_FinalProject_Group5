#pragma once
#include <array>
#include <string>
#include <vector>
#include "inventory_queue.h"
#include "types.h"

struct Product {
    std::string code, name, nameLower, category, categoryLower;
    double price = 0.0;
    std::array<int, NUM_BRANCHES> stock{};
    int networkStock() const;
};

class Catalog {
public:
    void build(const Inventory& inv);

    int findByCode(const std::string& code, int* steps = nullptr) const;

    std::vector<int> findByName(const std::string& prefixLower, int* steps = nullptr) const;

    std::vector<int> findByCategory(const std::string& prefixLower, int* steps = nullptr) const;
    std::vector<std::string> categories() const;
    const std::vector<Product>& products() const { return byCode_; }
    bool empty() const { return byCode_.empty(); }

private:
    std::vector<Product> byCode_;
    std::vector<int> nameIdx_;
    std::vector<int> catIdx_;
};

Catalog buildCatalog();
bool pickProduct(const Catalog& cat, int& index);
void printCatalog(const Catalog& cat, int myBranch);
void printProductCard(const Product& p, int myBranch);
void lookupMenu();
