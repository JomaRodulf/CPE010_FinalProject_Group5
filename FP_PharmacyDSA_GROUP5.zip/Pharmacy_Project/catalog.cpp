#include "catalog.h"
#include <algorithm>
#include <iostream>
#include <map>
#include "data_store.h"
#include "ui.h"
#include "util.h"

int Product::networkStock() const {
    int t = 0;
    for (int v : stock) t += v;
    return t;
}

void Catalog::build(const Inventory& inv) {
    std::map<std::string, Product> byCode;
    for (int b = 0; b < NUM_BRANCHES; ++b) {
        for (const Batch& x : inv[b].toVector()) {
            Product& p = byCode[x.code];
            if (p.code.empty()) {
                p.code = x.code; p.name = x.name; p.nameLower = toLower(x.name); p.price = x.price;
                p.category = x.category; p.categoryLower = toLower(x.category);
            }
            if (daysUntil(x.expiry) >= 0) p.stock[b] += x.qty;
        }
    }
    byCode_.clear();
    for (auto& kv : byCode) byCode_.push_back(kv.second);
    nameIdx_.resize(byCode_.size());
    for (size_t i = 0; i < nameIdx_.size(); ++i) nameIdx_[i] = static_cast<int>(i);
    std::sort(nameIdx_.begin(), nameIdx_.end(),
              [this](int a, int b) { return byCode_[a].nameLower < byCode_[b].nameLower; });
    catIdx_ = nameIdx_;
    std::sort(catIdx_.begin(), catIdx_.end(), [this](int a, int b) {
        if (byCode_[a].categoryLower != byCode_[b].categoryLower) return byCode_[a].categoryLower < byCode_[b].categoryLower;
        return byCode_[a].code < byCode_[b].code;
    });
}

std::vector<int> Catalog::findByCategory(const std::string& prefix, int* steps) const {
    int lo = 0, hi = static_cast<int>(catIdx_.size()), n = 0;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        ++n;
        if (byCode_[catIdx_[mid]].categoryLower < prefix) lo = mid + 1;
        else hi = mid;
    }
    if (steps) *steps = n;
    std::vector<int> hits;
    for (size_t i = lo; i < catIdx_.size(); ++i) {
        if (byCode_[catIdx_[i]].categoryLower.compare(0, prefix.size(), prefix) != 0) break;
        hits.push_back(catIdx_[i]);
    }
    return hits;
}

std::vector<std::string> Catalog::categories() const {
    std::vector<std::string> out;
    for (int i : catIdx_)
        if (out.empty() || out.back() != byCode_[i].category) out.push_back(byCode_[i].category);
    return out;
}

int Catalog::findByCode(const std::string& code, int* steps) const {
    int lo = 0, hi = static_cast<int>(byCode_.size()) - 1, n = 0;
    while (lo <= hi) {
        int mid = lo + (hi - lo) / 2;
        ++n;
        int cmp = code.compare(byCode_[mid].code);
        if (cmp == 0) { if (steps) *steps = n; return mid; }
        if (cmp < 0) hi = mid - 1;
        else lo = mid + 1;
    }
    if (steps) *steps = n;
    return -1;
}

std::vector<int> Catalog::findByName(const std::string& prefix, int* steps) const {
    int lo = 0, hi = static_cast<int>(nameIdx_.size()), n = 0;
    while (lo < hi) {
        int mid = lo + (hi - lo) / 2;
        ++n;
        if (byCode_[nameIdx_[mid]].nameLower < prefix) lo = mid + 1;
        else hi = mid;
    }
    if (steps) *steps = n;
    std::vector<int> hits;
    for (size_t i = lo; i < nameIdx_.size(); ++i) {
        const std::string& nm = byCode_[nameIdx_[i]].nameLower;
        if (nm.compare(0, prefix.size(), prefix) != 0) break;
        hits.push_back(nameIdx_[i]);
    }
    return hits;
}

Catalog buildCatalog() {
    Catalog c;
    Transaction tx(false);
    c.build(tx.state().inv);
    return c;
}

static std::string stockTag(int units) {
    if (units <= 0) return ui::red("OUT");
    if (units < LOW_STOCK_THRESHOLD) return ui::yellow("LOW");
    return "";
}

void printCatalog(const Catalog& cat, int myBranch) {
    printLine('=', 84);
    std::cout << fit("CODE", 9) << fit("MEDICINE", 24) << fit("CATEGORY", 23) << fit("PRICE", 11) << fit("MY BR.", 8)
              << fit("NETWORK", 8) << "NOTE\n";
    printLine('-', 84);
    for (const Product& p : cat.products()) {
        int mine = myBranch >= 0 ? p.stock[myBranch] : p.networkStock();
        std::cout << fit(p.code, 9) << fit(p.name, 24) << fit(p.category, 23) << fit(money(p.price), 11)
                  << fit(std::to_string(mine), 8) << fit(std::to_string(p.networkStock()), 8) << stockTag(mine) << "\n";
    }
    printLine('=', 84);
    std::cout << cat.products().size() << " medicine(s).  Stock shown = units that have not expired.\n";
}

void printProductCard(const Product& p, int myBranch) {
    std::cout << "\n" << ui::bold(p.code + "  " + p.name) << "   " << money(p.price) << " each   "
              << ui::dim("[" + p.category + "]") << "\n";
    printLine('-', 60);
    if (myBranch >= 0) {
        std::cout << "  Your branch (" << branchName(myBranch) << "): " << p.stock[myBranch] << " units "
                  << stockTag(p.stock[myBranch]) << "\n"
                  << "  All branches combined: " << p.networkStock() << " units\n";
    } else {
        for (int b = 0; b < NUM_BRANCHES; ++b)
            std::cout << "  " << fit(branchName(b), 28) << fit(std::to_string(p.stock[b]) + " units", 12)
                      << stockTag(p.stock[b]) << "\n";
        std::cout << "  " << fit("TOTAL", 28) << p.networkStock() << " units\n";
    }
    printLine('-', 60);
}

static bool chooseHit(const Catalog& cat, const std::vector<int>& hits, int& index) {
    if (hits.size() == 1) { index = hits[0]; return true; }
    for (size_t i = 0; i < hits.size(); ++i) {
        const Product& p = cat.products()[hits[i]];
        std::cout << "  " << i + 1 << ". " << fit(p.code, 9) << fit(p.name, 26) << ui::dim(p.category) << "\n";
    }
    int pick = readInt("Select a medicine (0 = search again): ", 0, static_cast<int>(hits.size()));
    if (pick == 0) return false;
    index = hits[pick - 1];
    return true;
}

bool pickProduct(const Catalog& cat, int& index) {
    if (cat.empty()) { ui::warn("The catalog is empty."); return false; }
    while (true) {
        std::string in = trim(readLine("Enter medicine code, name or category ('cat' lists categories; blank to cancel): "));
        if (in.empty()) return false;
        int steps = 0;
        std::string up = toUpper(in), low = toLower(in);

        if (low == "cat" || low == "categories") {
            std::vector<std::string> cats = cat.categories();
            for (size_t i = 0; i < cats.size(); ++i) std::cout << "  " << i + 1 << ". " << cats[i] << "\n";
            int c = readInt("Select a category (0 = search again): ", 0, static_cast<int>(cats.size()));
            if (c == 0) continue;
            std::vector<int> hits = cat.findByCategory(toLower(cats[c - 1]), &steps);
            std::vector<int> exact;
            for (int h : hits)
                if (cat.products()[h].category == cats[c - 1]) exact.push_back(h);
            std::cout << ui::dim("  Binary search by category: " + std::to_string(exact.size()) + " match(es) after " +
                                 std::to_string(steps) + " step(s).") << "\n";
            if (!exact.empty() && chooseHit(cat, exact, index)) return true;
            continue;
        }
        if (isValidCode(up)) {
            int i = cat.findByCode(up, &steps);
            if (i >= 0) {
                std::cout << ui::dim("  Binary search by code: found in " + std::to_string(steps) + " step(s).") << "\n";
                index = i;
                return true;
            }
            ui::err("No medicine with code " + up + " (binary search: " + std::to_string(steps) + " step(s)).");
            continue;
        }
        std::vector<int> hits = cat.findByName(low, &steps);
        if (!hits.empty()) {
            std::cout << ui::dim("  Binary search by name: " + std::to_string(hits.size()) + " match(es) after " +
                                 std::to_string(steps) + " step(s).") << "\n";
        } else {
            hits = cat.findByCategory(low, &steps);
            if (hits.empty()) {
                ui::err("No medicine or category starts with \"" + in + "\". Try a code (e.g. PAR0001), the first letters of "
                        "the name, or type 'cat' to see the categories.");
                continue;
            }
            std::cout << ui::dim("  Binary search by category: " + std::to_string(hits.size()) + " match(es) after " +
                                 std::to_string(steps) + " step(s).") << "\n";
        }
        if (chooseHit(cat, hits, index)) return true;
    }
}

void lookupMenu() {
    ui::header("MEDICINE LOOKUP (Binary Search)");
    while (true) {
        Catalog cat = buildCatalog();
        int idx;
        if (!pickProduct(cat, idx)) return;
        printProductCard(cat.products()[idx], -1);
    }
}
