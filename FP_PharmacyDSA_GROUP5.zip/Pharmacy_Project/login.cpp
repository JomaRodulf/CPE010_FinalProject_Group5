#include "login.h"
#include <cctype>
#include <iostream>
#include "util.h"

static const char* ADMIN_PASSCODE = "admin123";

bool validateName(const std::string& n) {
    if (n.size() < 2 || n.size() > 30) return false;
    for (char c : n)
        if (!std::isalpha(static_cast<unsigned char>(c)) && c != ' ' && c != '.' && c != '-') return false;
    return true;
}

static std::string askName() {
    while (true) {
        std::string n = trim(readLine("Enter your name: "));
        if (validateName(n)) return n;
        std::cout << "  Name must be 2-30 characters (letters, spaces, . or - only).\n";
    }
}

Session loginCustomer() {
    Session s;
    std::cout << "\n===== CENTRALIZED PHARMACY - CUSTOMER LOGIN =====\n";
    s.name = askName();
    std::cout << "\nPreferred city:\n";
    for (int i = 0; i < NUM_CITIES; ++i) std::cout << "  " << i + 1 << ". " << CITY_NAMES[i] << "\n";
    s.cityIdx = readInt("City: ", 1, NUM_CITIES) - 1;
    std::cout << "\nBranches in " << CITY_NAMES[s.cityIdx] << ":\n";
    for (int k = 0; k < BRANCHES_PER_CITY; ++k)
        std::cout << "  " << k + 1 << ". " << branchName(s.cityIdx * BRANCHES_PER_CITY + k) << "\n";
    s.branchId = s.cityIdx * BRANCHES_PER_CITY + readInt("Branch: ", 1, BRANCHES_PER_CITY) - 1;
    std::cout << "\nWelcome, " << s.name << "! Preferred branch: " << branchName(s.branchId) << "\n";
    return s;
}

bool loginAdmin(Session& s) {
    std::cout << "\n===== CENTRALIZED PHARMACY - ADMIN LOGIN =====\n";
    s.name = askName();
    s.isAdmin = true;
    for (int attempt = 1; attempt <= 3; ++attempt) {
        if (readLine("Admin passcode: ") == ADMIN_PASSCODE) {
            std::cout << "Access granted. Welcome, " << s.name << ".\n";
            return true;
        }
        std::cout << "  Wrong passcode (" << attempt << "/3).\n";
    }
    std::cout << "Too many failed attempts.\n";
    return false;
}

int chooseBranchFromAll(const std::string& prompt) {
    std::cout << "\n" << prompt << ":\n";
    for (int b = 0; b < NUM_BRANCHES; ++b) std::cout << "  " << (b < 9 ? " " : "") << b + 1 << ". " << branchName(b) << "\n";
    return readInt("Branch number: ", 1, NUM_BRANCHES) - 1;
}
