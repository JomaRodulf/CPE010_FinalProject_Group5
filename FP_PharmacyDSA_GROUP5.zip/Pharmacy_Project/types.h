#pragma once
#include <string>

constexpr int NUM_CITIES = 5;
constexpr int BRANCHES_PER_CITY = 2;
constexpr int NUM_BRANCHES = NUM_CITIES * BRANCHES_PER_CITY;
constexpr int LOW_STOCK_THRESHOLD = 30;
constexpr int EXPIRY_WARN_DAYS = 30;
constexpr int QUEUE_CAPACITY = 200;

extern const char* const CITY_NAMES[NUM_CITIES];
std::string branchName(int branchId);
inline int cityOfBranch(int branchId) { return branchId / BRANCHES_PER_CITY; }

struct Batch {
    std::string code;
    std::string name;
    int qty = 0;
    double price = 0.0;
    std::string expiry;
    std::string category = "General";
};

enum class OrderStatus { PENDING, SERVED, CANCELLED };
std::string statusToString(OrderStatus s);
OrderStatus statusFromString(const std::string& s);

struct Order {
    int id = 0;
    std::string customer;
    int branchId = 0;
    std::string code, name;
    int qty = 0;
    double unitPrice = 0.0, total = 0.0;
    OrderStatus status = OrderStatus::PENDING;
    std::string placedAt;
    std::string servedAt = "-";
    std::string allocation = "-";
    int fulfilledBranch = -1;
};

struct Session {
    std::string name;
    bool isAdmin = false;
    int cityIdx = -1;
    int branchId = -1;
};
