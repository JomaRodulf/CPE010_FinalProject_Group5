#include <algorithm>
#include <cstdlib>
#include <iostream>
#include <string>
#include <vector>
#include "benchmark.h"
#include "branch_graph.h"
#include "catalog.h"
#include "data_store.h"
#include "expiry_sort.h"
#include "inventory_queue.h"
#include "login.h"
#include "order_manager.h"
#include "types.h"
#include "ui.h"
#include "util.h"

namespace {

constexpr int MAX_CART_LINES = 10;
constexpr int MAX_QTY_PER_LINE = 100;

struct CartItem {
    std::string code, name;
    double price = 0.0;
    int qty = 0;
};

double cartTotal(const std::vector<CartItem>& cart) {
    double t = 0;
    for (const CartItem& c : cart) t += c.price * c.qty;
    return t;
}

void printCart(const std::vector<CartItem>& cart) {
    printLine('-', 78);
    std::cout << fit("#", 4) << fit("CODE", 9) << fit("MEDICINE", 28) << fit("QTY", 6) << fit("PRICE", 12) << "SUBTOTAL\n";
    printLine('-', 78);
    for (size_t i = 0; i < cart.size(); ++i)
        std::cout << fit(std::to_string(i + 1), 4) << fit(cart[i].code, 9) << fit(cart[i].name, 28)
                  << fit(std::to_string(cart[i].qty), 6) << fit(money(cart[i].price), 12)
                  << money(cart[i].price * cart[i].qty) << "\n";
    printLine('-', 78);
    std::cout << "TOTAL: " << ui::bold(money(cartTotal(cart))) << "\n";
}

void showNotices(const Session& s) {
    std::vector<std::string> notes = takeNotices(s.name);
    if (notes.empty()) return;
    std::cout << ui::yellow(" NEW NOTIFICATIONS") << "\n";
    for (const std::string& n : notes) std::cout << "  * " << n << "\n";
    std::cout << "\n";
}

void browseCatalog(const Session& s) {
    ui::header("MEDICINE CATALOG");
    ui::statusBar("Showing stock for " + branchName(s.branchId));
    Catalog cat = buildCatalog();
    printCatalog(cat, s.branchId);
    pauseScreen();
}

void searchAndAdd(const Session& s, std::vector<CartItem>& cart) {
    ui::header("SEARCH MEDICINE");
    Catalog cat = buildCatalog();
    int idx;
    if (!pickProduct(cat, idx)) return;
    const Product& p = cat.products()[idx];
    printProductCard(p, s.branchId);

    if (p.networkStock() == 0) {
        ui::err(p.name + " is currently unavailable in every branch.");
        pauseScreen();
        return;
    }
    if (!confirm("Add to cart?")) return;
    if (cart.size() >= static_cast<size_t>(MAX_CART_LINES) &&
        std::none_of(cart.begin(), cart.end(), [&](const CartItem& c) { return c.code == p.code; })) {
        ui::err("Your cart is full (" + std::to_string(MAX_CART_LINES) + " different medicines per order).");
        pauseScreen();
        return;
    }
    int qty = readInt("Quantity (1-" + std::to_string(MAX_QTY_PER_LINE) + "): ", 1, MAX_QTY_PER_LINE);

    auto it = std::find_if(cart.begin(), cart.end(), [&](const CartItem& c) { return c.code == p.code; });
    int want = qty + (it != cart.end() ? it->qty : 0);

    SourcePlan plan;
    {
        Transaction tx(false);
        plan = planSource(tx.state(), s.branchId, p.code, want);
    }
    if (!plan.found) {
        ui::err("Sorry, " + std::to_string(want) + " x " + p.name + " is not available in any single connected branch.");
        ui::warn("Try a smaller quantity.");
        pauseScreen();
        return;
    }
    if (plan.branch != s.branchId) {
        ui::warn("Your branch cannot fill " + std::to_string(want) + " units. " + branchName(plan.branch) + " (" +
                 std::to_string(plan.hops) + " hop(s) away) can.");
        if (!confirm("Order anyway and pick up there?")) return;
    }
    if (it != cart.end()) it->qty = want;
    else cart.push_back({p.code, p.name, p.price, qty});
    ui::ok("Added to cart.");
    pauseScreen();
}

void viewCart(std::vector<CartItem>& cart) {
    while (true) {
        ui::header("YOUR CART");
        if (cart.empty()) {
            std::cout << "Your cart is empty.\n";
            pauseScreen();
            return;
        }
        printCart(cart);
        int n = readInt("Enter a line number to remove it (0 = back): ", 0, static_cast<int>(cart.size()));
        if (n == 0) return;
        cart.erase(cart.begin() + (n - 1));
    }
}

void placeCartOrder(const Session& s, std::vector<CartItem>& cart) {
    ui::header("PLACE ORDER");
    if (cart.empty()) {
        ui::warn("Your cart is empty. Search for a medicine first.");
        pauseScreen();
        return;
    }
    printCart(cart);
    std::cout << "Pickup branch: " << branchName(s.branchId) << " (payment and pickup happen at the pharmacy)\n\n";
    if (!confirm("Place this order?")) return;

    int placed = 0;
    for (const CartItem& c : cart) {
        int id = placeOrder(s.name, s.branchId, c.code, c.name, c.price, c.qty);
        if (id < 0) {
            ui::err("The order queue is full. " + c.name + " was not placed - please try again later.");
            continue;
        }
        ++placed;
        ui::ok("Order #" + std::to_string(id) + " queued: " + std::to_string(c.qty) + " x " + c.name +
               "  (position " + std::to_string(queuePosition(id)) + " in line)");
    }
    if (placed > 0) std::cout << "\nOrders are served first-come, first-served. Check \"My orders\" for updates.\n";
    cart.clear();
    pauseScreen();
}

void myOrders(const Session& s) {
    while (true) {
        ui::header("MY ORDERS");
        showNotices(s);
        std::vector<Order> all = ordersOf(s.name);
        if (all.empty()) {
            std::cout << "You have no orders yet.\n";
            pauseScreen();
            return;
        }
        size_t from = all.size() > 12 ? all.size() - 12 : 0;
        printLine('-', 90);
        std::cout << fit("ORDER", 7) << fit("MEDICINE", 24) << fit("QTY", 5) << fit("TOTAL", 13) << fit("STATUS", 11)
                  << "DETAILS\n";
        printLine('-', 90);
        for (size_t i = from; i < all.size(); ++i) {
            const Order& o = all[i];
            std::string detail, status = fit(statusToString(o.status), 11);
            if (o.status == OrderStatus::PENDING) {
                int pos = queuePosition(o.id);
                detail = pos > 0 ? "waiting - position " + std::to_string(pos) : "being processed";
                status = ui::yellow(status);
            } else if (o.status == OrderStatus::SERVED) {
                detail = "pick up at " + branchName(o.fulfilledBranch >= 0 ? o.fulfilledBranch : o.branchId);
                status = ui::green(status);
            } else {
                detail = "cancelled / rejected";
                status = ui::red(status);
            }
            std::cout << fit("#" + std::to_string(o.id), 7) << fit(o.name, 24) << fit(std::to_string(o.qty), 5)
                      << fit(money(o.total), 13) << status << detail << "\n";
        }
        printLine('-', 90);
        int id = readInt("Enter an order # to cancel it (pending only), or 0 to go back: ", 0, 100000000);
        if (id == 0) return;
        if (cancelOrder(id, s.name)) ui::ok("Order #" + std::to_string(id) + " cancelled.");
        else ui::warn("Order #" + std::to_string(id) + " is not one of your pending orders.");
        pauseScreen();
    }
}

void customerMenu(Session& s) {
    std::vector<CartItem> cart;
    while (true) {
        ui::clear();
        ui::header("CUSTOMER MENU");
        ui::statusBar(s.name + "  |  " + branchName(s.branchId) + "  |  Cart: " + std::to_string(cart.size()) +
                      " item(s)  |  Orders waiting in queue: " + std::to_string(pendingCount()));
        showNotices(s);
        std::cout << " 1. Browse medicine catalog\n"
                  << " 2. Search medicine and add to cart\n"
                  << " 3. View / edit cart\n"
                  << " 4. Place order\n"
                  << " 5. My orders\n"
                  << " 0. Log out\n";
        int c = readInt("Choice: ", 0, 5);
        if (c == 0) {
            if (!cart.empty() && !confirm("Your cart is not empty. Log out and discard it?")) continue;
            return;
        }
        if (c == 1) browseCatalog(s);
        else if (c == 2) searchAndAdd(s, cart);
        else if (c == 3) viewCart(cart);
        else if (c == 4) placeCartOrder(s, cart);
        else myOrders(s);
    }
}

void dashboard() {
    ui::header("DASHBOARD");
    printLine('-', 60);
    std::cout << fit("BRANCH", 30) << fit("BATCHES", 10) << "SELLABLE UNITS\n";
    printLine('-', 60);
    {
        Transaction tx(false);
        for (int b = 0; b < NUM_BRANCHES; ++b)
            std::cout << fit(branchName(b), 30) << fit(std::to_string(tx.state().inv[b].size()), 10)
                      << tx.state().inv[b].totalUnits() << "\n";
    }
    printLine('-', 60);

    std::vector<Alert> alerts = currentAlerts();
    std::cout << "\n" << ui::yellow("ALERTS (" + std::to_string(alerts.size()) + ")") << "  - updated by the monitor thread\n";
    if (alerts.empty()) std::cout << "  None. All branches are above the minimum stock.\n";
    size_t shown = 0;
    for (const Alert& a : alerts) {
        if (++shown > 20) { std::cout << "  ... and " << alerts.size() - 20 << " more\n"; break; }
        std::cout << "  - " << a.text << "\n";
    }
    std::cout << "\nOrders waiting in queue: " << pendingCount() << "\n";
    pauseScreen();
}

void adminMenu(const Session& s) {
    while (true) {
        ui::clear();
        ui::header("ADMIN / BRANCH MANAGER MENU");
        ui::statusBar(s.name + "  |  Alerts: " + std::to_string(alertCount()) + "  |  Orders waiting: " +
                      std::to_string(pendingCount()));
        std::cout << " 1. Dashboard (stock overview + alerts)\n"
                  << " 2. Inventory management        (linked-list queue per branch)\n"
                  << " 3. Restock / sort by expiry    (insertion sort)\n"
                  << " 4. Order queue & processor     (circular queue + worker thread)\n"
                  << " 5. Branch network              (graph + BFS)\n"
                  << " 6. Lowest-stock finder & re-allocation\n"
                  << " 7. Medicine lookup             (binary search)\n"
                  << " 8. Performance analysis        (timing tests)\n"
                  << " 0. Log out\n";
        int c = readInt("Choice: ", 0, 8);
        if (c == 0) return;
        if (c == 1) dashboard();
        else if (c == 2) inventoryMenu();
        else if (c == 3) restockMenu();
        else if (c == 4) orderAdminMenu();
        else if (c == 5) branchMenu();
        else if (c == 6) rebalanceMenu();
        else if (c == 7) { lookupMenu(); }
        else benchmarkMenu();
    }
}

}

int main() {
    ui::init();
    loadData();
    requeuePendingOrders();
    startBackgroundThreads();
    std::atexit(stopBackgroundThreads);

    while (true) {
        ui::clear();
        ui::banner();
        std::cout << "\n  Online pharmacy ordering and inventory allocation for Quezon City, Marikina,\n"
                  << "  Antipolo, Pasig and Rizal branches.\n\n"
                  << " 1. Customer login\n"
                  << " 2. Admin / Branch manager login\n"
                  << " 0. Exit\n";
        int c = readInt("Choice: ", 0, 2);
        if (c == 1) {
            Session s = loginCustomer();
            customerMenu(s);
        } else if (c == 2) {
            Session s;
            if (loginAdmin(s)) adminMenu(s);
            else pauseScreen();
        } else {
            break;
        }
    }

    stopBackgroundThreads();
    std::cout << "\nThank you for using the Centralized Pharmacy Inventory and Allocation System.\n";
    return 0;
}
