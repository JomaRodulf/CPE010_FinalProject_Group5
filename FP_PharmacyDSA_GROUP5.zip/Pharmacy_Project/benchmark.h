#pragma once

void benchmarkMenu();
