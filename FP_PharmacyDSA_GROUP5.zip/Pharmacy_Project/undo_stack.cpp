#include "undo_stack.h"
#include <iostream>
#include <map>
#include "data_store.h"
#include "expiry_sort.h"
#include "ui.h"
#include "util.h"

void UndoStack::push(const StockChange& c) {
    top_ = new Node{c, top_};
    ++count_;
    if (count_ > MAX_HISTORY) {
        Node* prev = nullptr;
        Node* n = top_;
        while (n->next) { prev = n; n = n->next; }
        if (prev) prev->next = nullptr;
        delete n;
        --count_;
    }
}

bool UndoStack::pop(StockChange& out) {
    if (!top_) return false;
    Node* n = top_;
    out = n->data;
    top_ = n->next;
    delete n;
    --count_;
    return true;
}

bool UndoStack::peek(StockChange& out) const {
    if (!top_) return false;
    out = top_->data;
    return true;
}

std::vector<StockChange> UndoStack::toVector() const {
    std::vector<StockChange> v;
    for (Node* n = top_; n; n = n->next) v.push_back(n->data);
    return v;
}

void UndoStack::clear() {
    while (top_) { Node* n = top_; top_ = n->next; delete n; }
    count_ = 0;
}

static StockChange make(ChangeType t, int branch, const std::vector<Batch>& b) {
    StockChange c;
    c.type = t;
    c.branch = branch;
    c.batches = b;
    c.when = nowStr();
    return c;
}
StockChange makeAdded(int branch, const std::vector<Batch>& batches) { return make(ChangeType::ADD_BATCHES, branch, batches); }
StockChange makeReleased(int branch, const Batch& batch) { return make(ChangeType::RELEASE_FRONT, branch, {batch}); }
StockChange makeExpiredRemoved(int branch, const std::vector<Batch>& batches) { return make(ChangeType::REMOVE_EXPIRED, branch, batches); }
StockChange makeUpdated(int branch, const Batch& before, int newQty) {
    StockChange c = make(ChangeType::UPDATE_QTY, branch, {before});
    c.newQty = newQty;
    return c;
}

std::string StockChange::describe() const {
    std::string where = branchName(branch);
    std::string first = batches.empty() ? "" : batches[0].code + " " + batches[0].name;
    switch (type) {
        case ChangeType::ADD_BATCHES:
            return "Added " + std::to_string(batches.size()) + " batch(es) to " + where + " (" + first +
                   (batches.size() > 1 ? ", ..." : " x" + std::to_string(batches[0].qty)) + ")";
        case ChangeType::UPDATE_QTY:
            return "Changed " + batches[0].code + " (exp " + batches[0].expiry + ") in " + where + ": " +
                   std::to_string(batches[0].qty) + " -> " + std::to_string(newQty);
        case ChangeType::RELEASE_FRONT:
            return "Released front batch " + first + " x" + std::to_string(batches[0].qty) + " from " + where;
        default:
            return "Removed " + std::to_string(batches.size()) + " expired batch(es) from " + where;
    }
}

static bool findBatch(const BranchQueue& q, const std::string& code, const std::string& expiry, Batch& out) {
    for (const Batch& x : q.toVector())
        if (x.code == code && x.expiry == expiry) { out = x; return true; }
    return false;
}

bool applyUndo(AppState& s, const StockChange& c, std::string& msg) {
    BranchQueue& q = s.inv[c.branch];
    Batch cur;
    switch (c.type) {
        case ChangeType::ADD_BATCHES: {
            std::map<std::pair<std::string, std::string>, int> need;
            for (const Batch& b : c.batches) need[{b.code, b.expiry}] += b.qty;
            for (auto& kv : need)
                if (!findBatch(q, kv.first.first, kv.first.second, cur) || cur.qty < kv.second) {
                    msg = "Cannot undo: some of the added stock was already sold or changed.";
                    return false;
                }
            for (auto& kv : need) {
                findBatch(q, kv.first.first, kv.first.second, cur);
                q.updateQty(kv.first.first, kv.first.second, cur.qty - kv.second);
            }
            msg = "Removed the added batch(es) from " + branchName(c.branch) + ".";
            return true;
        }
        case ChangeType::UPDATE_QTY: {
            const Batch& before = c.batches[0];
            bool exists = findBatch(q, before.code, before.expiry, cur);
            if (c.newQty == 0) {
                q.restore(before);
            } else if (exists && cur.qty == c.newQty) {
                q.updateQty(before.code, before.expiry, before.qty);
            } else {
                msg = "Cannot undo: the batch quantity changed again after this update.";
                return false;
            }
            insertionSortByExpiry(q);
            msg = "Quantity of " + before.code + " (exp " + before.expiry + ") restored to " + std::to_string(before.qty) + ".";
            return true;
        }
        default: {
            for (const Batch& b : c.batches) q.restore(b);
            insertionSortByExpiry(q);
            msg = "Restored " + std::to_string(c.batches.size()) + " batch(es) to " + branchName(c.branch) +
                  " and re-sorted by expiry.";
            return true;
        }
    }
}

void undoLastUpdate() {
    StockChange c;
    {
        Transaction tx(false);
        if (!tx.state().undo.peek(c)) { ui::warn("Nothing to undo."); return; }
    }
    std::cout << "\nMost recent stock update (" << c.when << "):\n  " << c.describe() << "\n";
    if (!confirm("Undo it?")) return;

    std::string msg;
    bool ok, discard = false;
    {
        Transaction tx;
        StockChange top;
        if (!tx.state().undo.peek(top)) { ui::warn("Nothing to undo."); return; }
        ok = applyUndo(tx.state(), top, msg);
        if (ok) {
            tx.state().undo.pop(top);
            tx.commit();
        }
    }
    if (ok) {
        ui::ok(msg);
        return;
    }
    ui::err(msg);
    discard = confirm("Discard this history entry so you can undo earlier ones?");
    if (discard) {
        Transaction tx;
        StockChange gone;
        tx.state().undo.pop(gone);
        ui::ok("Entry discarded.");
    }
}

void showUpdateHistory() {
    std::vector<StockChange> h;
    {
        Transaction tx(false);
        h = tx.state().undo.toVector();
    }
    std::cout << "\nSTOCK UPDATE HISTORY (undo stack, newest first - top is undone first):\n";
    if (h.empty()) { std::cout << "  Empty.\n"; pauseScreen(); return; }
    printLine('-', 90);
    for (size_t i = 0; i < h.size(); ++i)
        std::cout << (i == 0 ? " TOP> " : "      ") << h[i].when << "  " << h[i].describe() << "\n";
    printLine('-', 90);
    pauseScreen();
}
