#include "data_store.h"
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include "expiry_sort.h"
#include "util.h"

namespace fs = std::filesystem;

namespace {
AppState g_state;
std::mutex g_stockMutex;

const char* DIR = "data";
const char* INV_FILE = "data/inventory.csv";
const char* ORDER_FILE = "data/orders.csv";
const char* LINK_FILE = "data/links.csv";

void saveInventory(const AppState& s) {
    std::ofstream f(INV_FILE);
    f << std::fixed << std::setprecision(2);
    f << "branch,code,name,qty,price,expiry,category\n";
    for (int b = 0; b < NUM_BRANCHES; ++b)
        for (const Batch& x : s.inv[b].toVector())
            f << b << ',' << x.code << ',' << x.name << ',' << x.qty << ',' << x.price << ',' << x.expiry << ',' << x.category << '\n';
}

void saveOrders(const AppState& s) {
    std::ofstream f(ORDER_FILE);
    f << std::fixed << std::setprecision(2);
    f << "id,customer,branch,code,name,qty,unitPrice,total,status,placedAt,servedAt,allocation,fulfilledBranch\n";
    for (const Order& o : s.orders)
        f << o.id << ',' << o.customer << ',' << o.branchId << ',' << o.code << ',' << o.name << ',' << o.qty << ','
          << o.unitPrice << ',' << o.total << ',' << statusToString(o.status) << ',' << o.placedAt << ','
          << o.servedAt << ',' << o.allocation << ',' << o.fulfilledBranch << '\n';
}

void saveLinks(const AppState& s) {
    std::ofstream f(LINK_FILE);
    f << "branchA,branchB\n";
    for (auto& e : s.graph.edges()) f << e.first << ',' << e.second << '\n';
}

struct Med { const char* code; const char* name; double price; const char* category; };
const Med MEDS[] = {
    {"PAR0001", "Paracetamol 500mg", 3.50, "Pain & Fever"},   {"CET0001", "Cetirizine 10mg", 8.00, "Allergy"},
    {"LOR0001", "Loratadine 10mg", 12.00, "Allergy"},         {"AMO0001", "Amoxicillin 500mg", 15.00, "Antibiotic"},
    {"AML0001", "Amlodipine 5mg", 10.00, "Heart & Blood Pressure"}, {"IBU0001", "Ibuprofen 200mg", 5.50, "Pain & Fever"},
    {"MET0001", "Metformin 500mg", 6.00, "Diabetes"},         {"LOS0001", "Losartan 50mg", 9.00, "Heart & Blood Pressure"},
    {"ATO0001", "Atorvastatin 20mg", 18.00, "Heart & Blood Pressure"}, {"OME0001", "Omeprazole 20mg", 11.00, "Digestive"},
    {"VIT0001", "Vitamin C 500mg", 4.00, "Vitamins"},         {"CAR0001", "Carbocisteine 500mg", 13.00, "Respiratory"},
    {"SAL0001", "Salbutamol 2mg", 7.50, "Respiratory"},       {"ORS0001", "Oral Rehydration Salts", 6.00, "Digestive"},
    {"MEF0001", "Mefenamic Acid 500mg", 7.00, "Pain & Fever"}};

std::string categoryForCode(const std::string& code) {
    for (const Med& m : MEDS)
        if (code == m.code) return m.category;
    return "General";
}

void loadInventory(AppState& s) {
    std::ifstream f(INV_FILE);
    std::string line;
    std::getline(f, line);
    int bad = 0;
    while (std::getline(f, line)) {
        if (trim(line).empty()) continue;
        auto c = splitCSV(line);
        try {
            if (c.size() < 6) throw std::runtime_error("short");
            int b = std::stoi(c[0]);
            if (b < 0 || b >= NUM_BRANCHES) throw std::runtime_error("branch");
            Batch x;
            x.code = c[1]; x.name = c[2]; x.qty = std::stoi(c[3]); x.price = std::stod(c[4]); x.expiry = c[5];
            x.category = (c.size() > 6 && !trim(c[6]).empty()) ? trim(c[6]) : categoryForCode(x.code);
            s.inv[b].enqueue(x);
        } catch (...) { ++bad; }
    }
    if (bad) std::cout << "Warning: skipped " << bad << " malformed line(s) in " << INV_FILE << "\n";
}

void loadOrders(AppState& s) {
    std::ifstream f(ORDER_FILE);
    if (!f) return;
    std::string line;
    std::getline(f, line);
    while (std::getline(f, line)) {
        if (trim(line).empty()) continue;
        auto c = splitCSV(line);
        try {
            if (c.size() < 12) continue;
            Order o;
            o.id = std::stoi(c[0]); o.customer = c[1]; o.branchId = std::stoi(c[2]); o.code = c[3]; o.name = c[4];
            o.qty = std::stoi(c[5]); o.unitPrice = std::stod(c[6]); o.total = std::stod(c[7]);
            o.status = statusFromString(c[8]); o.placedAt = c[9]; o.servedAt = c[10]; o.allocation = c[11];
            if (c.size() > 12) o.fulfilledBranch = std::stoi(c[12]);
            s.orders.push_back(o);
        } catch (...) {}
    }
}

void loadLinks(AppState& s) {
    std::ifstream f(LINK_FILE);
    std::string line;
    std::getline(f, line);

    for (auto& e : s.graph.edges()) s.graph.removeEdge(e.first, e.second);
    while (std::getline(f, line)) {
        auto c = splitCSV(line);
        try { if (c.size() >= 2) s.graph.addEdge(std::stoi(c[0]), std::stoi(c[1])); } catch (...) {}
    }
}

void seedInventory(AppState& s) {
    unsigned seed = 20260611u;
    auto rnd = [&seed](int lo, int hi) {
        seed = seed * 1103515245u + 12345u;
        return lo + static_cast<int>((seed >> 16) % static_cast<unsigned>(hi - lo + 1));
    };

    for (int b = 0; b < NUM_BRANCHES; ++b) {
        for (const Med& m : MEDS) {
            int batches = rnd(1, 3);
            for (int k = 0; k < batches; ++k) {
                Batch x;
                x.code = m.code; x.name = m.name; x.price = m.price; x.category = m.category;
                x.qty = (rnd(0, 9) == 0) ? rnd(5, 18) : rnd(20, 120);
                x.expiry = addDaysToToday(rnd(40, 720));
                s.inv[b].enqueue(x);
            }
        }
    }

    Batch soon{"PAR0001", "Paracetamol 500mg", 40, 3.50, addDaysToToday(12)};
    Batch gone{"IBU0001", "Ibuprofen 200mg", 25, 5.50, addDaysToToday(-5)};
    soon.category = gone.category = "Pain & Fever";
    s.inv[0].enqueue(soon);
    s.inv[3].enqueue(gone);
    for (auto& q : s.inv) insertionSortByExpiry(q);
}
}

Transaction::Transaction(bool writable) : lock_(g_stockMutex), writable_(writable) {}

AppState& Transaction::state() { return g_state; }

void Transaction::commit() {
    if (!writable_) return;
    saveInventory(g_state);
    saveOrders(g_state);
    saveLinks(g_state);
}

void loadData() {
    fs::create_directories(DIR);
    Transaction tx;
    AppState& s = tx.state();
    if (fs::exists(INV_FILE)) {
        loadInventory(s);
    } else {
        seedInventory(s);
        std::cout << "First run: sample inventory created in " << INV_FILE << "\n";
    }
    loadOrders(s);
    if (fs::exists(LINK_FILE)) loadLinks(s);
    tx.commit();
}

Order* findOrder(AppState& s, int id) {
    if (id >= 1 && id <= static_cast<int>(s.orders.size()) && s.orders[id - 1].id == id) return &s.orders[id - 1];
    for (Order& o : s.orders)
        if (o.id == id) return &o;
    return nullptr;
}

std::vector<std::pair<std::string, int>> parseAllocation(const std::string& alloc) {
    std::vector<std::pair<std::string, int>> out;
    size_t pos = 0;
    while (pos < alloc.size()) {
        size_t end = alloc.find(';', pos);
        if (end == std::string::npos) end = alloc.size();
        std::string part = alloc.substr(pos, end - pos);
        size_t colon = part.find(':');
        if (colon != std::string::npos) {
            try { out.push_back({part.substr(0, colon), std::stoi(part.substr(colon + 1))}); } catch (...) {}
        }
        pos = end + 1;
    }
    return out;
}
