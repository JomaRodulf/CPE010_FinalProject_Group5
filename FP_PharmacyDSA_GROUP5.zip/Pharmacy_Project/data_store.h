#pragma once
#include <mutex>
#include <string>
#include <utility>
#include <vector>
#include "branch_graph.h"
#include "inventory_queue.h"
#include "types.h"
#include "undo_stack.h"

struct AppState {
    Inventory inv;
    BranchGraph graph;
    std::vector<Order> orders;
    UndoStack undo;
};

class Transaction {
public:
    explicit Transaction(bool writable = true);
    Transaction(const Transaction&) = delete;
    Transaction& operator=(const Transaction&) = delete;

    AppState& state();
    void commit();

private:
    std::unique_lock<std::mutex> lock_;
    bool writable_;
};

void loadData();
Order* findOrder(AppState& s, int id);

std::vector<std::pair<std::string, int>> parseAllocation(const std::string& alloc);
