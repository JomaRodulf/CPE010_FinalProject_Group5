#include "ui.h"
#include <iostream>

#ifdef _WIN32
#define NOMINMAX
#include <windows.h>
#ifndef ENABLE_VIRTUAL_TERMINAL_PROCESSING
#define ENABLE_VIRTUAL_TERMINAL_PROCESSING 0x0004
#endif
#else
#include <unistd.h>
#endif

namespace {
bool g_color = false;

std::string paint(const char* code, const std::string& s) {
    return g_color ? std::string("\033[") + code + "m" + s + "\033[0m" : s;
}

std::string center(const std::string& s, int width) {
    int pad = width - static_cast<int>(s.size());
    if (pad < 0) pad = 0;
    int left = pad / 2;
    return std::string(left, ' ') + s + std::string(pad - left, ' ');
}
}

namespace ui {

void init() {
#ifdef _WIN32
    HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD mode = 0;
    if (h != INVALID_HANDLE_VALUE && GetConsoleMode(h, &mode))
        g_color = SetConsoleMode(h, mode | ENABLE_VIRTUAL_TERMINAL_PROCESSING) != 0;
#else
    g_color = isatty(1) != 0;
#endif
}

void clear() {
    if (g_color) std::cout << "\033[2J\033[H";
    else std::cout << "\n";
}

std::string cyan(const std::string& s) { return paint("36", s); }
std::string green(const std::string& s) { return paint("32", s); }
std::string yellow(const std::string& s) { return paint("33", s); }
std::string red(const std::string& s) { return paint("31", s); }
std::string bold(const std::string& s) { return paint("1", s); }
std::string dim(const std::string& s) { return paint("2", s); }

void banner() {
    const int W = 76;
    std::string edge = "+" + std::string(W, '-') + "+";
    std::cout << cyan(edge) << "\n"
              << cyan("|") << bold(center("CENTRALIZED PHARMACY INVENTORY AND ALLOCATION SYSTEM", W)) << cyan("|") << "\n"
              << cyan("|") << center("CPE 010 - Data Structures and Algorithms  |  Group 5", W) << cyan("|") << "\n"
              << cyan(edge) << "\n";
}

void header(const std::string& title) {
    std::cout << "\n" << cyan(std::string(78, '=')) << "\n " << bold(title) << "\n"
              << cyan(std::string(78, '=')) << "\n";
}

void statusBar(const std::string& text) { std::cout << dim(" " + text) << "\n\n"; }

void ok(const std::string& msg) { std::cout << green("[OK] ") << msg << "\n"; }
void warn(const std::string& msg) { std::cout << yellow("[!]  ") << msg << "\n"; }
void err(const std::string& msg) { std::cout << red("[X]  ") << msg << "\n"; }

}
