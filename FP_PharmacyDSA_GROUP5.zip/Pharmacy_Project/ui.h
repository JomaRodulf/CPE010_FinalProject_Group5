#pragma once
#include <string>

namespace ui {
void init();
void clear();
void banner();
void header(const std::string& title);
void statusBar(const std::string& text);

std::string cyan(const std::string& s);
std::string green(const std::string& s);
std::string yellow(const std::string& s);
std::string red(const std::string& s);
std::string bold(const std::string& s);
std::string dim(const std::string& s);

void ok(const std::string& msg);
void warn(const std::string& msg);
void err(const std::string& msg);
}
