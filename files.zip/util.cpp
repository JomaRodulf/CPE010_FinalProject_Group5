#include "util.h"
#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iomanip>
#include <iostream>
#include <mutex>
#include <sstream>

std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}
std::string toLower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::tolower(c); });
    return s;
}
std::string toUpper(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return std::toupper(c); });
    return s;
}
std::vector<std::string> splitCSV(const std::string& line) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : line) {
        if (c == ',') { out.push_back(cur); cur.clear(); }
        else if (c != '\r' && c != '\n') cur += c;
    }
    out.push_back(cur);
    return out;
}

std::string readLine(const std::string& prompt) {
    std::cout << prompt << std::flush;
    std::string s;
    if (!std::getline(std::cin, s)) {
        std::cout << "\nInput closed. Exiting.\n";
        std::exit(0);
    }
    return s;
}
int readInt(const std::string& prompt, int lo, int hi) {
    while (true) {
        std::string s = trim(readLine(prompt));
        try {
            size_t pos = 0;
            int v = std::stoi(s, &pos);
            if (pos == s.size() && v >= lo && v <= hi) return v;
        } catch (...) {}
        std::cout << "  Please enter a number from " << lo << " to " << hi << ".\n";
    }
}
double readDouble(const std::string& prompt, double lo, double hi) {
    while (true) {
        std::string s = trim(readLine(prompt));
        try {
            size_t pos = 0;
            double v = std::stod(s, &pos);
            if (pos == s.size() && v >= lo && v <= hi) return v;
        } catch (...) {}
        std::cout << "  Please enter an amount from " << lo << " to " << hi << ".\n";
    }
}
bool confirm(const std::string& prompt) {
    while (true) {
        std::string s = toLower(trim(readLine(prompt + " (y/n): ")));
        if (s == "y" || s == "yes") return true;
        if (s == "n" || s == "no") return false;
    }
}
void pauseScreen() { readLine("\nPress ENTER to continue..."); }

// localtime is not thread-safe, so guard it (background threads also call these)
static std::tm localTm(std::time_t t) {
    static std::mutex m;
    std::lock_guard<std::mutex> lk(m);
    return *std::localtime(&t);
}
static std::string fmtTime(std::time_t t, const char* f) {
    std::tm tm = localTm(t);
    char buf[64];
    std::strftime(buf, sizeof buf, f, &tm);
    return buf;
}
std::string todayStr() { return fmtTime(std::time(nullptr), "%Y-%m-%d"); }
std::string nowStr() { return fmtTime(std::time(nullptr), "%Y-%m-%d %H:%M:%S"); }
std::string addDaysToToday(int days) {
    return fmtTime(std::time(nullptr) + static_cast<std::time_t>(days) * 86400, "%Y-%m-%d");
}

static bool parseDate(const std::string& d, int& y, int& m, int& dd) {
    if (d.size() != 10 || d[4] != '-' || d[7] != '-') return false;
    for (size_t i = 0; i < d.size(); ++i)
        if (i != 4 && i != 7 && !std::isdigit(static_cast<unsigned char>(d[i]))) return false;
    y = std::stoi(d.substr(0, 4)); m = std::stoi(d.substr(5, 2)); dd = std::stoi(d.substr(8, 2));
    static const int dim[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (m < 1 || m > 12 || dd < 1) return false;
    int maxd = dim[m - 1];
    if (m == 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) maxd = 29;
    return dd <= maxd;
}
bool isValidDate(const std::string& d) { int y, m, dd; return parseDate(d, y, m, dd); }

int daysUntil(const std::string& date) {
    int y, m, d;
    if (!parseDate(date, y, m, d)) return 100000;
    std::tm a{};
    a.tm_year = y - 1900; a.tm_mon = m - 1; a.tm_mday = d; a.tm_hour = 12; a.tm_isdst = -1;
    std::tm b = localTm(std::time(nullptr));
    b.tm_hour = 12; b.tm_min = 0; b.tm_sec = 0; b.tm_isdst = -1;
    return static_cast<int>(std::lround(std::difftime(std::mktime(&a), std::mktime(&b)) / 86400.0));
}

std::string money(double v) {
    std::ostringstream os;
    os << "PHP " << std::fixed << std::setprecision(2) << v;
    return os.str();
}
std::string fit(const std::string& s, size_t w) {
    if (s.size() > w) return s.substr(0, w - 1) + "~";
    return s + std::string(w - s.size(), ' ');
}
void printLine(char c, int n) { std::cout << std::string(n, c) << "\n"; }
