// login.h - Feature 1: Login System (name + preferred city/branch; admin passcode)
#pragma once
#include <string>
#include "types.h"

bool validateName(const std::string& name);
Session loginCustomer();            // asks name, preferred city, preferred branch
bool loginAdmin(Session& s);        // asks name + passcode (3 attempts)
int chooseBranchFromAll(const std::string& prompt);   // returns 0-based branch id
