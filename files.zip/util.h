// util.h - input, string, date and formatting helpers
#pragma once
#include <string>
#include <vector>

std::string trim(const std::string& s);
std::string toLower(std::string s);
std::string toUpper(std::string s);
std::vector<std::string> splitCSV(const std::string& line);

std::string readLine(const std::string& prompt);
int readInt(const std::string& prompt, int lo, int hi);
double readDouble(const std::string& prompt, double lo, double hi);
bool confirm(const std::string& prompt);
void pauseScreen();

std::string todayStr();                 // YYYY-MM-DD
std::string nowStr();                   // YYYY-MM-DD HH:MM:SS
std::string addDaysToToday(int days);
bool isValidDate(const std::string& d);
int daysUntil(const std::string& date); // negative = already expired

std::string money(double v);
std::string fit(const std::string& s, size_t width);
void printLine(char c = '-', int n = 78);
