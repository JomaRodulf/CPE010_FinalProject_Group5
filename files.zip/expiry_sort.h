// expiry_sort.h - Feature 6: Leftover Medicine Stock Arrangement (INSERTION SORT, Admin only)
// On restock: leftover batches + new batches are merged, then insertion-sorted by
// expiry date so the soonest-to-expire batch is at the FRONT of the FIFO queue.
#pragma once
#include <vector>
#include "inventory_queue.h"

void insertionSortByExpiry(BranchQueue& q);                              // stable, linked-list insertion sort
void restockBranch(BranchQueue& q, const std::vector<Batch>& incoming);  // merge + sort
void restockMenu();                                                      // Admin menu
