// inventory_queue.h - Feature 2: Inventory Management (Linked-List QUEUE, FIFO)
// One queue per branch. Each node is a batch. New stock is enqueued at the REAR,
// the oldest / soonest-to-expire batch sits at the FRONT (see expiry_sort.h).
#pragma once
#include <array>
#include <string>
#include <vector>
#include "types.h"

struct BatchNode {
    Batch data;
    BatchNode* next;
};

class BranchQueue {
public:
    BranchQueue() = default;
    ~BranchQueue() { clear(); }
    BranchQueue(const BranchQueue&) = delete;
    BranchQueue& operator=(const BranchQueue&) = delete;

    // --- queue operations ---
    void enqueue(const Batch& b);                 // add at rear
    bool dequeue(Batch& out);                     // release front batch
    const Batch* peekFront() const { return head_ ? &head_->data : nullptr; }
    int size() const { return count_; }
    bool empty() const { return count_ == 0; }
    void clear();

    // --- stock operations ---
    int sellableStock(const std::string& code) const;      // non-expired units of a code
    int totalUnits() const;                                // all non-expired units
    bool findInfo(const std::string& code, Batch& out) const;
    bool deductFIFO(const std::string& code, int qty, std::string& allocation);
    void restore(const Batch& b);                          // put stock back (cancelled order)
    bool updateQty(const std::string& code, const std::string& expiry, int newQty);
    int removeExpired();
    std::vector<Batch> toVector() const;
    void display(int limit = -1) const;

    // used by insertion sort (expiry_sort.cpp)
    BatchNode* detachAll();
    void attachList(BatchNode* newHead);

private:
    BatchNode* head_ = nullptr;
    BatchNode* tail_ = nullptr;
    int count_ = 0;
    void unlink(BatchNode* prev, BatchNode* cur);
};

using Inventory = std::array<BranchQueue, NUM_BRANCHES>;

bool isValidCode(const std::string& code);       // 3 letters + 4 digits
bool promptNewBatch(Batch& out);                 // interactive batch entry
void printLowStock(const BranchQueue& q);
void printExpiringSoon(const BranchQueue& q);
void inventoryMenu();                            // Admin menu
